README:

This executable works with the Maps file but only the admin tool works.

The maps are broken when you try to find a route as usual. Pretty sure it is a simple variable issue within FileChooser.

For general understanding please refer to our user manual.