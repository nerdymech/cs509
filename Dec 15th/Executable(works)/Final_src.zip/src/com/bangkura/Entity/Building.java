package com.bangkura.Entity;

public class Building {
    private int buildingID;
	private String name;
    private int xCooridinate;
    private int yCooridinate;
    private int numberOfFloors;
    
    
    public int getBuildingID() {
		return buildingID;
	}
	public void setBuildingID(int buildingID) {
		this.buildingID = buildingID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getxCooridinate() {
		return xCooridinate;
	}
	public void setxCooridinate(int xCooridinate) {
		this.xCooridinate = xCooridinate;
	}
	public int getyCooridinate() {
		return yCooridinate;
	}
	public void setyCooridinate(int yCooridinate) {
		this.yCooridinate = yCooridinate;
	}
	public int getNumberOfFloors() {
		return numberOfFloors;
	}
	public void setNumberOfFloors(int numberOfFloors) {
		this.numberOfFloors = numberOfFloors;
	}

    
      
}
