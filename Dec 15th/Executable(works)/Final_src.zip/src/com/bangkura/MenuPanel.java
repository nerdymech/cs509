package com.bangkura;

public class MenuPanel {

}
