package com.bangkura;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.bangkura.Entity.Admin;
import com.bangkura.Entity.Edge;
import com.bangkura.Entity.User;

public class Main {
	public static void main(String[] args) {
		GPS gps = new GPS();
	}
}
